/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package metodo_delete;
import connection.connection;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import javax.swing.JOptionPane;


/**
 *
 * @author germain
 */
public class delete_usuario {
     public static Connection con;
public delete_usuario(){
connection conx = new connection();
con = conx.conexion();
}
public void borrar_usuario (
String usuario,
String password){
    
    int rows;
            String sql = "execute sp_login_eliminar @p_id_usuario = " + usuario +", @p_pass = " + "'"+ password + "'" + "";// comando SQL insert
            CallableStatement  callableStatement = null;
        
  try{
            callableStatement   = con.prepareCall(sql);   
            rows = callableStatement.executeUpdate();
             JOptionPane.showMessageDialog(null,rows +" usuario(s) eliminado(s) ","Exito",
                     JOptionPane.INFORMATION_MESSAGE);
        con.commit();
        callableStatement.close();
        con.close();
    }catch(SQLException ex){
           JOptionPane.showMessageDialog(null, "No se pudo eliminar el usuario", "mensaje de error" ,JOptionPane.ERROR_MESSAGE);
         JOptionPane.showMessageDialog(null,ex, "mensaje de error" ,JOptionPane.ERROR_MESSAGE);       
    }
            }
}
