/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package metodo_insert;

import connection.connection;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
/**
 *
 * @author germain
 */
public class insert_venta {
      public static Connection con;
public insert_venta(){
connection conx = new connection();
con = conx.conexion();
}
public void insertar_usuario (
            String no_serie,
            String id_cliente,
            String enganche,
            String tipo_pago,
            String plazo){
          
              ResultSet rs;
              int rows;
              String sql = "execute sp_venta_insertar @p_no_serie = " + "'"+ no_serie + "'"
                      + ", @p_id_cliente = " + "'"+ id_cliente + "'"
                      + ",@p_enganche = " + enganche + ","
                      + "@p_tipo_pago = '" + tipo_pago + "',"
                      + "@p_plazo =" + plazo +"";
              CallableStatement  callableStatement = null;
              try {
              
              callableStatement   = con.prepareCall(sql);
              rows = callableStatement.executeUpdate();
              JOptionPane.showMessageDialog(null," Venta agregado","Exito",
                      JOptionPane.INFORMATION_MESSAGE);
              con.commit();
              callableStatement.close();
              con.close();
          } catch (SQLException ex) {
             JOptionPane.showMessageDialog(null, "no se pudo agregar la venta","Error",
                     JOptionPane.ERROR_MESSAGE);
           JOptionPane.showMessageDialog(null, ex,"Error",
                     JOptionPane.ERROR_MESSAGE);
    }
}
            

public void insertar_ventafija (){
          
              
              int rows;
              String sql = "execute sp_venta_fija";
              CallableStatement  callableStatement = null;
              try {
              
              callableStatement   = con.prepareCall(sql);
              rows = callableStatement.executeUpdate();
              con.commit();
              callableStatement.close();
              con.close();
          } catch (SQLException ex) {
             JOptionPane.showMessageDialog(null, "no se pudo agregar la venta","Error",
                     JOptionPane.ERROR_MESSAGE);
           JOptionPane.showMessageDialog(null, ex,"Error",
                     JOptionPane.ERROR_MESSAGE);
    }
}
}
