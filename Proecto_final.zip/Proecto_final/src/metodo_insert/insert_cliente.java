/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package metodo_insert;
import connection.connection;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import static metodo_insert.insert_usuario.con;
/**
 *
 * @author germain
 */
public class insert_cliente {
          public static Connection con;
public insert_cliente(){
connection conx = new connection();
con = conx.conexion();
}
  
  public void insertar_cliente(
  String nombre,
  String direccion,
  String correo,
  String telefono,
  String rfc){
           
        
            int rows;
            String sql = "execute sp_cliente_agregar @p_nombre = " + "'"+ nombre + "'" + ", @p_direccion = " + "'"+ direccion + "'" + ", @p_correo = " + "'"+ correo + "'" + ", @p_telefono = " + "'"+ telefono + "'" + ", @p_rfc = '" + rfc +"'";// comando SQL insert
            CallableStatement  callableStatement = null;
        
  try{
            callableStatement   = con.prepareCall(sql);   
            rows = callableStatement.executeUpdate();
             JOptionPane.showMessageDialog(null,rows +" clientes(s) agregado(s)","Exito",
                     JOptionPane.INFORMATION_MESSAGE);
             consulta();
        con.commit();
        callableStatement.close();
        con.close();
    }catch(SQLException ex){
                     JOptionPane.showMessageDialog(null,ex+"","Error",
                     JOptionPane.ERROR_MESSAGE);
            }
            }
  static void consulta() {
         try {
             Statement stmt; // instruccion SQL
             String query;
// consulta SQL
ResultSet rs;
// resultados del SQL query
boolean mas;
// "mas registros en la consulta"
// forma sentencia SQL de consulta
query = "sp_mostrar_id_cliente";
stmt = con.createStatement();
rs = stmt.executeQuery(query);
// revisa si hay mas registros por leer del resultado
mas = rs.next();
if (!mas) {
    System.out.println("No hay registros para la consulta.");
    return;
}
Integer id_cliente;
// ciclo para obtener los resultados de la consulta
while (mas) {
    id_cliente = rs.getInt("id_cliente");
    JOptionPane.showMessageDialog(null,"su numero de cliente es: " +id_cliente);
    mas = rs.next();
}
rs.close();
// cierra el resultado
stmt.close(); // cierra la sentencia SQL
         } catch (SQLException ex) {
             Logger.getLogger(insert_usuario.class.getName()).log(Level.SEVERE, null, ex);
         }
}
  
  
}
