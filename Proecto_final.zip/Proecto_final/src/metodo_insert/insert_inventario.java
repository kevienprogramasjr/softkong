/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package metodo_insert;

import connection.connection;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import javax.swing.JOptionPane;


/**
 *
 * @author germain
 */
public class insert_inventario {
           public static Connection con;
public insert_inventario(){
connection conx = new connection();
con = conx.conexion();
}

public void agregar_inventario(
        String no_serie,
        String modelo,
        String year,
        String marca,
        String descripcion,
        String precio_compra,
        String precio_venta){
    
    
            int rows;
            String sql = "execute sp_inventario_agregar @p_no_serie = " + "'"+ no_serie 
                    + "'" + ", @p_modelo = " + "'"+ modelo 
                    + "'" + ", @p_year = " + "'"+ year 
                    + "'" + ", @p_marca = " + "'"+ marca
                    + "'" + ", @p_descripcion = " + "'"+ descripcion
                    + "'" + ", @p_precio_compra = "+ precio_compra
                    + ",       @p_precio_venta = " + precio_venta + "" ;// comando SQL insert
            CallableStatement  callableStatement = null;
        
  try{
            callableStatement   = con.prepareCall(sql);   
            rows = callableStatement.executeUpdate();
             JOptionPane.showMessageDialog(null,rows +" auto(s) agregado(s)","Exito",
                     JOptionPane.INFORMATION_MESSAGE);
        con.commit();
        callableStatement.close();
        con.close();
    }catch(SQLException ex){
        JOptionPane.showMessageDialog(null, ex);
            }
        

}
}
