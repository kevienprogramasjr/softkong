/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package metodo_insert;
import connection.connection;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;


/**
 *
 * @author germain
 */
public class insert_usuario {
     public static Connection con;
public insert_usuario(){
connection conx = new connection();
con = conx.conexion();


}
public void insertar_usuario (

        String usuario,
        String password        
){
              int rows;
            String sql = "execute sp_login_alta @p_usuario = " + "'"+ usuario + "'" + ", @p_password = " + "'"+ password + "'";// comando SQL insert
            CallableStatement  callableStatement = null;
        
  try{
            callableStatement   = con.prepareCall(sql);   
            rows = callableStatement.executeUpdate();
             JOptionPane.showMessageDialog(null,rows +" usuario agregado\n", "Exito",
                     JOptionPane.INFORMATION_MESSAGE);
             consulta();
        con.commit();
        callableStatement.close();
        con.close();
    }catch(SQLException ex){
           System.out.println("No se pudo agregar el usuario ");
    }
            }

static void consulta() {
         try {
             Statement stmt; // instruccion SQL
             String query;
// consulta SQL
ResultSet rs;
// resultados del SQL query
boolean mas;
// "mas registros en la consulta"
// forma sentencia SQL de consulta
query = "sp_mostrar_login_insertado";
stmt = con.createStatement();
rs = stmt.executeQuery(query);
// revisa si hay mas registros por leer del resultado
mas = rs.next();
if (!mas) {
    System.out.println("No hay registros para la consulta.");
    return;
}
Integer id_usuario;
// ciclo para obtener los resultados de la consulta
while (mas) {
    id_usuario = rs.getInt("id_usuario");
    JOptionPane.showMessageDialog(null,"su numero de usuario es: " +id_usuario);
    mas = rs.next();
}
rs.close();
// cierra el resultado
stmt.close(); // cierra la sentencia SQL
         } catch (SQLException ex) {
             Logger.getLogger(insert_usuario.class.getName()).log(Level.SEVERE, null, ex);
         }
}
// fin de metodo consulta
// fin de clase ConexionSQLServer


}

