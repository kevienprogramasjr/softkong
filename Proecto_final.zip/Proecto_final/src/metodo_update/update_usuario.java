/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package metodo_update;
import connection.connection;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author germain
 */
public class update_usuario {
      public static Connection con;
public update_usuario(){
connection conx = new connection();
con = conx.conexion();
    
}

public void login_usuario (
String usuario,
String password,
String pass_modificado){
    
    int rows;
            String sql = "sp_login_modificar @p_id_usuario ="
                    +usuario+ "" + ",@p_password_actual ="
                    + "'" + password + "'" + ",@p_pass_modificado ="
                   +"'" +pass_modificado+"'";
            CallableStatement  callableStatement = null;
        
  try{
            callableStatement   = con.prepareCall(sql);   
            rows = callableStatement.executeUpdate();
             JOptionPane.showMessageDialog(null,rows +" usuario modificado","Exito",
                     JOptionPane.INFORMATION_MESSAGE);
        con.commit();
        callableStatement.close();
        con.close();
    }catch(SQLException ex){
         JOptionPane.showMessageDialog(null, ex,"mensaje de error", 
                     JOptionPane.INFORMATION_MESSAGE);
            }
            }
}
