/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package metodo_update;

import connection.connection;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import javax.swing.JOptionPane;


/**
 *
 * @author germain
 */
public class update_login {
    public static Connection con;
public update_login(){
connection conx = new connection();
con = conx.conexion();
}
public void usuario_login (
String usuario,
String password){
    
    int rows;
            String sql = "execute sp_login_consulta @p_idusuario = " + usuario +", @p_password = " + "'"+ password + "'" + "" ;// comando SQL insert
            CallableStatement  callableStatement = null;
        
  try{
            callableStatement   = con.prepareCall(sql);   
            rows = callableStatement.executeUpdate();
             JOptionPane.showMessageDialog(null," ingreso satisfactoriamente","Exito",
                     JOptionPane.INFORMATION_MESSAGE);
        con.commit();
        callableStatement.close();
        con.close();
    }catch(SQLException ex){
           System.out.println("No pudo ingresar");
            }
            }
}
