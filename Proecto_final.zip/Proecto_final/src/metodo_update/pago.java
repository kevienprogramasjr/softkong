/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package metodo_update;

import connection.connection;
import java.sql.CallableStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import static metodo_update.update_correo.con;

/**
 *
 * @author germain
 */
public class pago {
    public pago(){
connection conx = new connection();
con = conx.conexion();
}
    public void pago_credito (
String id_venta,
String pago){
    
    int rows;
            String sql = "execute sp_venta_abono  @p_id_venta = " + id_venta +", @p_pago = " + pago  + "" ;// comando SQL insert
            CallableStatement  callableStatement = null;
        
  try{
            callableStatement   = con.prepareCall(sql);   
            rows = callableStatement.executeUpdate();
             JOptionPane.showMessageDialog(null,rows +" pago(s) efectuado(s)","Exito",
                     JOptionPane.INFORMATION_MESSAGE);
        con.commit();
        callableStatement.close();
        con.close();
    }catch(SQLException ex){
          JOptionPane.showMessageDialog(null, ex);
            }
            }
}
