/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package metodo_update;
import connection.connection;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author germain
 */
public class update_direccion {
         public static Connection con;
public update_direccion(){
connection conx = new connection();
con = conx.conexion();

} 
public void cliente_direccion (
String id_cliente,
String direccion){
    
    int rows;
            String sql = "execute sp_cliente_modificar_direccion  @p_id_cliente = " + id_cliente +", @p_direccion = " + "'"+ direccion + "'" + "" ;// comando SQL insert
            CallableStatement  callableStatement = null;
        
  try{
            callableStatement   = con.prepareCall(sql);   
            rows = callableStatement.executeUpdate();
             JOptionPane.showMessageDialog(null,rows +" Direccion modificada","Exito",
                     JOptionPane.INFORMATION_MESSAGE);
        con.commit();
        callableStatement.close();
        con.close();
    }catch(SQLException ex){
           System.out.println("No se pudo modificar la direccion");
            }
            }

}
