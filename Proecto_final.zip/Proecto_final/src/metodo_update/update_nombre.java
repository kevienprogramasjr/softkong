/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package metodo_update;
import connection.connection;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author germain
 */
public class update_nombre {
    public static Connection con;
public update_nombre(){
connection conx = new connection();
con = conx.conexion();
}
public void cliente_nombre( 
String id_cliente,
 String nombre){
    
    int rows;
            String sql = "execute sp_cliente_modificar_nombre  @p_id_cliente = " + id_cliente +", @p_nombre = " + "'"+ nombre + "'" + "" ;// comando SQL insert
            CallableStatement  callableStatement = null;
        
  try{
            callableStatement   = con.prepareCall(sql);   
            rows = callableStatement.executeUpdate();
             JOptionPane.showMessageDialog(null,rows +" nombre modificado","Exito",
                     JOptionPane.INFORMATION_MESSAGE);
        con.commit();
        callableStatement.close();
        con.close();
    }catch(SQLException ex){
           System.out.println("No se pudo modificar el nombre");
            }
            }   
}
