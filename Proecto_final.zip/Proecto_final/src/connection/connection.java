/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author germain
 */
public class connection {
      public static Connection con;
    public Connection conexion(){
    
    try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
           String connectionUrl = "jdbc:sqlserver://GERMAIN-PC\\SQL2012:0;" +
                   "databaseName=proyecto_final;user=user1;password=usuario2016;";
           con = DriverManager.getConnection(connectionUrl);
            
           
    } catch (SQLException e) {
    } catch (ClassNotFoundException cE) {System.out.println("su conexion ha fallado: "+ cE.toString());
    }
    
    
    return con;
    }
}
