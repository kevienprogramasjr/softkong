package proecto_final;

import java.sql.DriverManager;
import java.sql.SQLException;
import static proecto_final.venta.con;

public class Proecto_final {
public static void main(String[] args) {
    splash_screen ss = new splash_screen();
    ss.show();
}

public void connection() {
          try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
           String connectionUrl = "jdbc:sqlserver://GERMAIN-PC\\SQL2012:0;" + "databaseName=proyecto_final;user=user1;password=usuario2016;";
           con = DriverManager.getConnection(connectionUrl);
            
           
    } catch (SQLException e) {
    } catch (ClassNotFoundException cE) {System.out.println("su conexion ha fallado: "+ cE.toString());
    }
    }
}




