package proecto_final;
import java.awt.print.*;
import java.awt.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Date;
import javax.swing.JOptionPane;
import metodo_select.*;

public class jfactura extends javax.swing.JFrame implements Printable
{
    public jfactura() {
        initComponents();
        this.setLocationRelativeTo(null);
        factura f = new factura();
        f.consulta();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pfactura = new javax.swing.JPanel();
        lblfolio = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblfactuta = new javax.swing.JTable();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        lblfecha = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        lbldireccion = new javax.swing.JLabel();
        lblrfc = new javax.swing.JLabel();
        lblid = new javax.swing.JLabel();
        lblcliente = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        lbltotal = new javax.swing.JLabel();
        lbln2l = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        btnimprimir = new javax.swing.JButton();
        btncerrar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("KONG COMPANY");

        pfactura.setBackground(new java.awt.Color(255, 255, 255));
        pfactura.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        pfactura.setPreferredSize(new java.awt.Dimension(2550, 3300));
        pfactura.setLayout(null);

        lblfolio.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        lblfolio.setText("A");
        lblfolio.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        pfactura.add(lblfolio);
        lblfolio.setBounds(300, 30, 50, 17);

        tblfactuta.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        tblfactuta.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "no_serie", "modelo", "marca", "año", "precio venta"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tblfactuta);

        pfactura.add(jScrollPane1);
        jScrollPane1.setBounds(20, 240, 378, 50);

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 10)); // NOI18N
        jLabel6.setText("NT: 123134134");
        pfactura.add(jLabel6);
        jLabel6.setBounds(150, 30, 90, 13);
        jLabel6.getAccessibleContext().setAccessibleName("lblnt");

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 10)); // NOI18N
        pfactura.add(jLabel7);
        jLabel7.setBounds(10, 20, 30, 0);

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        jLabel8.setText("Santa fe #1200 colonia la fe");
        pfactura.add(jLabel8);
        jLabel8.setBounds(130, 40, 122, 13);

        lblfecha.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        lblfecha.setText("a");
        pfactura.add(lblfecha);
        lblfecha.setBounds(330, 60, 50, 10);

        jLabel10.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        jLabel10.setText("zona 7 Nuevo Leon - México");
        pfactura.add(jLabel10);
        jLabel10.setBounds(130, 50, 140, 13);

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 10)); // NOI18N
        jLabel11.setText("TEL: 81-12-99-60-23");
        pfactura.add(jLabel11);
        jLabel11.setBounds(140, 60, 120, 13);

        jLabel12.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        jLabel12.setText("email: kongcompany@gmail.com");
        pfactura.add(jLabel12);
        jLabel12.setBounds(120, 70, 150, 13);

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 10)); // NOI18N
        jLabel9.setText("fecha:");
        pfactura.add(jLabel9);
        jLabel9.setBounds(290, 60, 30, 13);

        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel13.setText("KONG COMPANY");
        pfactura.add(jLabel13);
        jLabel13.setBounds(130, 10, 118, 17);

        jLabel14.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel14.setText("FACTURA");
        jLabel14.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        pfactura.add(jLabel14);
        jLabel14.setBounds(290, 10, 70, 19);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        lbldireccion.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lbldireccion.setText("Direccion:");
        lbldireccion.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        lblrfc.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lblrfc.setText("RFC:");
        lblrfc.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        lblid.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lblid.setText("ID:");
        lblid.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        lblcliente.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lblcliente.setText("Cliente:");
        lblcliente.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lbldireccion, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(lblid, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblrfc, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(lblcliente, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(lblcliente)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lbldireccion)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblrfc)
                    .addComponent(lblid))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pfactura.add(jPanel1);
        jPanel1.setBounds(10, 140, 390, 70);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        lbltotal.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lbltotal.setText("RFC:");
        lbltotal.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        lbln2l.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lbln2l.setText("RFC:");
        lbln2l.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap(265, Short.MAX_VALUE)
                .addComponent(lbltotal, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addComponent(lbln2l, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(lbltotal)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lbln2l)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pfactura.add(jPanel2);
        jPanel2.setBounds(10, 430, 390, 50);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/archivos/ico.png"))); // NOI18N
        pfactura.add(jLabel1);
        jLabel1.setBounds(10, 10, 100, 110);

        btnimprimir.setText("IMPRIMIR");
        btnimprimir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnimprimirActionPerformed(evt);
            }
        });

        btncerrar.setText("CERRAR");
        btncerrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btncerrarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btncerrar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnimprimir)
                .addContainerGap())
            .addComponent(pfactura, javax.swing.GroupLayout.DEFAULT_SIZE, 407, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(pfactura, javax.swing.GroupLayout.DEFAULT_SIZE, 527, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnimprimir)
                    .addComponent(btncerrar))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    

    
    private void btncerrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btncerrarActionPerformed
dispose();
    }//GEN-LAST:event_btncerrarActionPerformed

    private void btnimprimirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnimprimirActionPerformed
try
{
  PrinterJob gap = PrinterJob.getPrinterJob();
  gap.setPrintable(this);
  boolean top = gap.printDialog();
  if (top){
      gap.print();
  }
          
}
catch(PrinterException pex)
        {
          JOptionPane.showMessageDialog(null, pex, "error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnimprimirActionPerformed
    public static void main(String args[]) {
       //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(jfactura.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        java.awt.EventQueue.invokeLater(() -> {
            new jfactura().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btncerrar;
    private javax.swing.JButton btnimprimir;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    public static javax.swing.JLabel lblcliente;
    public static javax.swing.JLabel lbldireccion;
    public static javax.swing.JLabel lblfecha;
    public static javax.swing.JLabel lblfolio;
    public static javax.swing.JLabel lblid;
    public static javax.swing.JLabel lbln2l;
    public static javax.swing.JLabel lblrfc;
    public static javax.swing.JLabel lbltotal;
    private javax.swing.JPanel pfactura;
    public static javax.swing.JTable tblfactuta;
    // End of variables declaration//GEN-END:variables

    @Override
    public int print(Graphics graf, PageFormat pagfor, int index) throws PrinterException 
    {
        if(index>0){
            return NO_SUCH_PAGE;
        }
    Graphics2D hub = (Graphics2D) graf;
    hub.translate(pagfor.getImageableX() * 30, pagfor.getImageableY() * 30);
    hub.scale(1.5, 1.5);
    pfactura.paintAll(graf);
    return PAGE_EXISTS;
    }
    
}
