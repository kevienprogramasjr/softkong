/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package metodo_select;

import connection.connection;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import proecto_final.*;

public class select_ventatemp {
    public static Connection con;
public select_ventatemp(){
connection conx = new connection();
con = conx.conexion();
}
public void consulta() {
        try {
           
            Proecto_final pf = new Proecto_final();
            pf.connection();
            Statement stmt; // instruccion
            PreparedStatement ps;
            ResultSetMetaData rsm;
            DefaultTableModel dtm;
            ResultSet rs;
            CallableStatement  callableStatement;   

         
          
            
            String sql = "sp_venta_monstrar";// comando SQL insert
            callableStatement   = con.prepareCall(sql);
        
            rs =  callableStatement.executeQuery();
            rsm = rs.getMetaData();
            ArrayList <Object[]> data = new ArrayList<>();
            while (rs.next())
            {
                Object[] rows = new Object[rsm.getColumnCount()];
                for (int i = 0; i < rows.length; i++){
                    rows[i] =rs.getObject(i+1);
                }
                data.add(rows);
            }
            dtm =(DefaultTableModel) venta.jventatemp.getModel();
            for(int i = 0; i< data.size(); i++){
                dtm.addRow(data.get(i));
                con.close();
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex, "mensaje de error", JOptionPane.ERROR_MESSAGE);
        }
          }
    
}
