/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package metodo_select;

import connection.connection;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import metodo_insert.insert_usuario;
import static metodo_select.cliente_todo.con;
import proecto_final.jfactura;
import metodo_select.n2t;
import proecto_final.Proecto_final;
import proecto_final.buscar_cliente;

/**
 *
 * @author germain
 */
public class factura {
     public static Connection con;
public factura(){
connection conx = new connection();
con = conx.conexion();
}
public void consulta() {
         try {
             Statement stmt; // instruccion SQL
             String query;
// consulta SQL
ResultSet rs;
// resultados del SQL query
boolean mas;
// "mas registros en la consulta"
// forma sentencia SQL de consulta
query = "sp_lbl_factura";
stmt = con.createStatement();
rs = stmt.executeQuery(query);
// revisa si hay mas registros por leer del resultado
mas = rs.next();
if (!mas) {
    System.out.println("No hay registros para la consulta.");
    return;
}

// ciclo para obtener los resultados de la consulta
while (mas) {
    String cliente = rs.getString("nombre");
    Integer folio = rs.getInt("id_venta");
    String fecha = rs.getString("fecha_venta");
    String direccion = rs.getString("direccion");
    Integer id_cliente = rs.getInt("id_cliente");
    String rfc = rs.getString("rfc");
    Integer precio = rs.getInt("precio_venta");
    jfactura.lblcliente.setText("cliente: "+cliente);
    jfactura.lblfolio.setText("A "+folio);
    jfactura.lblfecha.setText(fecha);
    jfactura.lbldireccion.setText("Direccion: "+ direccion);
    jfactura.lblid.setText("ID Cliente: " + id_cliente);
    jfactura.lblrfc.setText("RFC: "+rfc);
    jfactura.lbltotal.setText("total: $"+ precio+".00");
    mas = rs.next();
     Integer numeros = precio;
     n2t numero = new n2t(); 
		numero = new n2t(numeros);
		 String res = numero.convertirLetras(numeros);
                 jfactura.lbln2l.setText(res + " pesos 00/100 M.N");
                 consulta_factura();
}
rs.close();
// cierra el resultado
stmt.close(); // cierra la sentencia SQL
         } catch (SQLException ex) {
             Logger.getLogger(insert_usuario.class.getName()).log(Level.SEVERE, null, ex);
         }
        
}
public void consulta_factura() {
        try {
           
            Proecto_final pf = new Proecto_final();
            pf.connection();
            Statement stmt; // instruccion
            PreparedStatement ps;
            ResultSetMetaData rsm;
            DefaultTableModel dtm;
            ResultSet rs;
            CallableStatement  callableStatement;   

         
          
            
            String sql = "sp_factura_tabla";// comando SQL insert
            callableStatement   = con.prepareCall(sql);
        
            rs =  callableStatement.executeQuery();
            rsm = rs.getMetaData();
            ArrayList <Object[]> data = new ArrayList<>();
            while (rs.next())
            {
                Object[] rows = new Object[rsm.getColumnCount()];
                for (int i = 0; i < rows.length; i++){
                    rows[i] =rs.getObject(i+1);
                }
                data.add(rows);
            }
            dtm =(DefaultTableModel) jfactura.tblfactuta.getModel();
            for(int i = 0; i< data.size(); i++){
                dtm.addRow(data.get(i));
                con.close();
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex, "mensaje de error", JOptionPane.ERROR_MESSAGE);
        }
          }
 
}