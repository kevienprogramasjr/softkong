/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package metodo_select;

import connection.connection;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;
import proecto_final.buscar_auto;

/**
 *
 * @author germain
 */
public class select_buscar_auto {
     public static Connection con;
public select_buscar_auto(){
connection conx = new connection();
con = conx.conexion();
}
public void consultas (String modelo) {
        try {
            Statement stmt; // instruccion
            PreparedStatement ps;
            ResultSetMetaData rsm;
            DefaultTableModel dtm;
            ResultSet rs;
            CallableStatement  callableStatement;   
            
            String sql = "execute sp_inventario_consulta @p_modelo = '"+modelo +"'";// comando SQL insert
            
            callableStatement   = con.prepareCall(sql);
            rs =  callableStatement.executeQuery();
            rsm = rs.getMetaData();
            ArrayList <Object[]> data = new ArrayList<>();
            while (rs.next())
            {
                Object[] rows = new Object[rsm.getColumnCount()];
                for (int i = 0; i < rows.length; i++){
                    rows[i] =rs.getObject(i+1);
                }
                data.add(rows);
            }
            dtm =(DefaultTableModel)buscar_auto.Jtable_auto.getModel();
            for(int i = 0; i< data.size(); i++){
                System.out.println(i);
                dtm.addRow(data.get(i));
            }
        } catch (SQLException ex) {
            Logger.getLogger(proecto_final.buscar_auto.class.getName()).log(Level.SEVERE, null, ex);
        }
          }
public void consulta_todo () {
        try {
            Statement stmt; // instruccion
            PreparedStatement ps;
            ResultSetMetaData rsm;
            DefaultTableModel dtm;
            ResultSet rs;
            CallableStatement  callableStatement;   
            
            String sql = "sp_inventario_consulta_todo";// comando SQL insert
            
            callableStatement   = con.prepareCall(sql);
            rs =  callableStatement.executeQuery();
            rsm = rs.getMetaData();
            ArrayList <Object[]> data = new ArrayList<>();
            while (rs.next())
            {
                Object[] rows = new Object[rsm.getColumnCount()];
                for (int i = 0; i < rows.length; i++){
                    rows[i] =rs.getObject(i+1);
                }
                data.add(rows);
            }
            dtm =(DefaultTableModel)buscar_auto.Jtable_auto.getModel();
            for(int i = 0; i< data.size(); i++){
                System.out.println(i);
                dtm.addRow(data.get(i));
            }
        } catch (SQLException ex) {
            Logger.getLogger(proecto_final.buscar_auto.class.getName()).log(Level.SEVERE, null, ex);
        }
          }
}
